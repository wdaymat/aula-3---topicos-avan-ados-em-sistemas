const TaskManager = require("./Tasks");
let taskManager = new TaskManager();
taskManager.addTask("estudar js");
taskManager.addTask("estudar node");
taskManager.addTask("treinar diitação");
const tarefa = taskManager.getTaks();
tarefa.forEach((t,index) =>{
    console.log(`${index+1} - ${t}`)
})