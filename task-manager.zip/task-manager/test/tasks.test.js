const TaskManager = require("../src/Tasks");
describe("gerenciador de tarefas", ()=>{
    let taskManager;
    beforeEach(()=>{
        taskManager = new TaskManager();

    });

    test("add nova tarefa", ()=>{
        taskManager.addTask("estudar jest");
        expect(taskManager.getTasks())
                            .toContain("estudar jest");

    });

    test("lista inicia vazia", ()=>{
        expect(taskManager.getTasks()).toEqual([]);
    });

    test("limpar a lista", ()=>{
        taskManager.addTask("comprar pao");
        taskManager.clearTasks();
        expect(taskManager.getTasks()).toEqual([]);
    });

    test("dar um erro se entras com dados incorretos",()=>{
        expect(()=> taskManager.addTask(123)).toThrow("tarefa invalida.");
    });

})